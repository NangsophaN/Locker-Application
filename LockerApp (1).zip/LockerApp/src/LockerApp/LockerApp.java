package LockerApp;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LockerApp extends JFrame {
    private String password;
    private JTextField passwordField;
    private JLabel statusLabel;

    public LockerApp() {
        setTitle("Locker Application");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        passwordField = new JTextField(20);
        JButton enterButton = new JButton("Enter");
        statusLabel = new JLabel();

        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputPassword = passwordField.getText();
                if (password == null) {
                    password = inputPassword;
                    statusLabel.setText("Password Set");
                } else {
                    if (inputPassword.equals(password)) {
                        statusLabel.setText("Correct Password");
                    } else {
                        statusLabel.setText("Incorrect Password");
                    }
                }
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Enter Password:"));
        panel.add(passwordField);
        panel.add(enterButton);
        panel.add(statusLabel);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        new LockerApp();
    }
}